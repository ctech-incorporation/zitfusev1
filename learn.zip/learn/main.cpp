#include <iostream>
#include <string>
#include <fstream>
#define clear "cls"
using namespace std;

int main()
{
    string name, username1, username, password1, password;
    int choise;

    cout << "Hello User Please Enter An Option\n1)Login\n2)Create An Account\nChoise: ";
    cin >> choise;
    system(clear);
    if (choise == 1)
    {

    repeatLogin:
        cout << "To Login Please Enter the Username\nUsername: ";
        cin >> username1;
        system(clear);
        cout << "Please Enter the Password\nPassword: ";
        cin >> password1;
        if (username == username1 && password == password1)
        {
            cout << "Hello " << name << " You Have Logged in Successfully" << endl;
        }
        else
        {
            cout << "Username or Password Incorrect\nPlease try Again" << endl;
            goto repeatLogin;
        }
    }

    else if (choise == 2)
    {

        cout << "TO CREATE AN ACCOUNT PLEASE ENTER THE FOLLOWING" << endl;
        cout << "Please enter your Name\nName: ";
        cin.ignore();
        getline(cin, name);
        system(clear);
        cout << "Please Enter Username\nUsername: ";
        cin >> username;
        system(clear);
        cout << "Please Create Password\nPassword: ";
        cin >> password;
        system(clear);
        cout << "Account Created Successfully" << endl;
        goto repeatLogin;
    }
    return 0;
}